# Osmanlı Tarayıcı

Osmanlı / Selçuklu esintili koyu lacivert-altın arayüzlü Android WebView tarayıcı başlangıç projesi.

## GitHub Actions ile APK derleme
1. ZIP dosyasını çıkarın.
2. İçindeki `OsmanliTarayici_GitHub` klasörünün içeriğini GitHub deposunun ana dizinine yükleyin.
3. GitHub'da **Actions** sekmesini açın.
4. **Osmanlı Tarayıcı APK Derle** iş akışını seçin.
5. **Run workflow** düğmesine basın.
6. İşlem bitince derlemenin **Artifacts** bölümünden `Osmanli-Tarayici-APK` dosyasını indirin.
7. ZIP içindeki APK artifact'ini açıp `app-debug.apk` dosyasını telefona kurun.

## İçerik
- Google arama / adres çubuğu
- WebView tabanlı web sayfası görüntüleme
- Favoriler ve ziyaret geçmişi
- İndirme yöneticisine yönlendirme
- Basit gizli mod anahtarı (gizli moddayken yeni geçmiş kaydı eklenmez)
- Ana sayfada hızlı bağlantılar
- İki kullanıcı görselinden hazırlanan tema görselleri

## Önemli notlar
Bu ilk sürüm bir başlangıç tarayıcısıdır; Chromium tabanlı Chrome motorunu değil, Android System WebView motorunu kullanır. Sekme düğmesi şimdilik sekme sayısını gösteren temel bir arayüzdür; gerçek çoklu sekme yönetimi henüz eklenmemiştir. Reklam engelleme, gelişmiş güvenlik koruması ve tam gizli oturum izolasyonu bu sürümde yoktur.
